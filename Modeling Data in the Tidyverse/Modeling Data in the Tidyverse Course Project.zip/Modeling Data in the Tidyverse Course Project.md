# Modeling Data in the Tidyverse Course Project

***

## Project Description

In this course, we have learned about modeling data in the Tidyverse in R. This project will give you the opportunity to practice those skills in greater depth. 

Here, we will continue to use consumer complaints data from the Consumer Complaint Database (CFPB) that was used in the Wranging Data in the Tidyverse Course Project. The CFPB is an independent agency of the United States government that promotes transparency and protects consumers by providing information needed to make decisions when choosing financial institutions including banking institutions, lenders, mortgage services, credit unions, securities firms, foreclosure services, and debt collectors. One of the purposes of the agency is to receive and process complaints and questions about consumer financial products and services. 

When a complaint is submitted by a consumer, the CFPB has to determine which category the complaint falls in (e.g. "Mortgage", "Student loan", etc). In this project, your goal will be to use the skills you have learned about in this course to build a classification algorithm to classify consumer complaints into one of four categories: "Credit card or prepaid card", "Mortgage", "Student loan", or "Vehicle loan or lease". 

## Import Libraries


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import random

import sklearn

# import shap
# import eli5
# from IPython.display import display
import statsmodels.api as sm

import datetime
from datetime import datetime, timedelta


import scipy.stats

#import pandas_profiling
#from pandas_profiling import ProfileReport

#import graphviz

#import xgboost as xgb
#from xgboost import XGBClassifier, XGBRegressor
#from xgboost import to_graphviz, plot_importance

#from sklearn.experimental import enable_hist_gradient_boosting
#from sklearn.linear_model import ElasticNet, Lasso, LinearRegression, LogisticRegression, Ridge
#from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, ExtraTreesClassifier, ExtraTreesRegressor
from sklearn.ensemble import GradientBoostingClassifier


%matplotlib inline
#sets the default autosave frequency in seconds
%autosave 60 
sns.set_style('dark')
sns.set(font_scale=1.2)

plt.rc('axes', labelsize=14)
plt.rc('xtick', labelsize=12)
plt.rc('ytick', labelsize=12)


from sklearn.model_selection import cross_val_score, train_test_split, GridSearchCV, RandomizedSearchCV
from sklearn.model_selection import cross_validate, KFold, RepeatedStratifiedKFold
from sklearn.preprocessing import LabelEncoder, StandardScaler, MinMaxScaler, OneHotEncoder
#from sklearn.pipeline import Pipeline
#from sklearn.feature_selection import RFE, RFECV, SelectKBest, f_classif, f_regression, chi2
#from sklearn.inspection import permutation_importance

from sklearn.tree import export_graphviz, plot_tree
from sklearn.metrics import confusion_matrix, classification_report, mean_absolute_error, mean_squared_error,r2_score
from sklearn.metrics import plot_confusion_matrix, plot_precision_recall_curve, plot_roc_curve, accuracy_score
from sklearn.metrics import auc, f1_score, precision_score, recall_score, roc_auc_score


#from tpot import TPOTClassifier, TPOTRegressor
#from imblearn.under_sampling import RandomUnderSampler
#from imblearn.over_sampling import RandomOverSampler
#from imblearn.over_sampling import SMOTE

import warnings
warnings.filterwarnings('ignore')


# Use Feature-Engine library

#import feature_engine.missing_data_imputers as mdi
#from feature_engine.outlier_removers import Winsorizer
#from feature_engine import categorical_encoders as ce


#from pycaret.classification import *
#from pycaret.clustering import *
#from pycaret.regression import *

pd.set_option('display.max_columns',None)
#pd.set_option('display.max_rows',100)
pd.set_option('display.width', 1000)
pd.set_option('display.float_format','{:.2f}'.format)


random.seed(0)
np.random.seed(0)
np.set_printoptions(suppress=True)
```



    Autosaving every 60 seconds
    

## Exploratory Data Analysis


```python
df = pd.read_csv("data_complaints_train.csv")
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Consumer complaint narrative</th>
      <th>Company</th>
      <th>State</th>
      <th>ZIP code</th>
      <th>Submitted via</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Credit card or prepaid card</td>
      <td>I initially in writing to Chase Bank in late X...</td>
      <td>JPMORGAN CHASE &amp; CO.</td>
      <td>CT</td>
      <td>064XX</td>
      <td>Web</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mortgage</td>
      <td>My ex husband and myself had a mobile home ( H...</td>
      <td>Ditech Financial LLC</td>
      <td>GA</td>
      <td>None</td>
      <td>Web</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Student loan</td>
      <td>I was a student at XXXX XXXX from XX/XX/XXXX-X...</td>
      <td>Navient Solutions, LLC.</td>
      <td>IN</td>
      <td>463XX</td>
      <td>Web</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Credit card or prepaid card</td>
      <td>It has come to my attention the CITI group is ...</td>
      <td>CITIBANK, N.A.</td>
      <td>MI</td>
      <td>490XX</td>
      <td>Web</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Credit card or prepaid card</td>
      <td>This banks new firearm policies run counter to...</td>
      <td>CITIBANK, N.A.</td>
      <td>MI</td>
      <td>480XX</td>
      <td>Web</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>90970</th>
      <td>Credit card or prepaid card</td>
      <td>This involves a Chase Advantage ( checking ) a...</td>
      <td>JPMORGAN CHASE &amp; CO.</td>
      <td>WV</td>
      <td>260XX</td>
      <td>Web</td>
    </tr>
    <tr>
      <th>90971</th>
      <td>Vehicle loan or lease</td>
      <td>I sent a letter to XXXX  in XXXX, with signatu...</td>
      <td>Byrider Franchising, LLC</td>
      <td>LA</td>
      <td>703XX</td>
      <td>Web</td>
    </tr>
    <tr>
      <th>90972</th>
      <td>Student loan</td>
      <td>One component of the PSLF program that I and s...</td>
      <td>AES/PHEAA</td>
      <td>VA</td>
      <td>None</td>
      <td>Web</td>
    </tr>
    <tr>
      <th>90973</th>
      <td>Credit card or prepaid card</td>
      <td>i have been an american express customer for y...</td>
      <td>AMERICAN EXPRESS COMPANY</td>
      <td>NJ</td>
      <td>None</td>
      <td>Web</td>
    </tr>
    <tr>
      <th>90974</th>
      <td>Mortgage</td>
      <td>They committed fraud and raised my escrow amou...</td>
      <td>CITIZENS FINANCIAL GROUP, INC.</td>
      <td>NY</td>
      <td>123XX</td>
      <td>Web</td>
    </tr>
  </tbody>
</table>
<p>90975 rows × 6 columns</p>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 90975 entries, 0 to 90974
    Data columns (total 6 columns):
     #   Column                        Non-Null Count  Dtype 
    ---  ------                        --------------  ----- 
     0   Product                       90975 non-null  object
     1   Consumer complaint narrative  90975 non-null  object
     2   Company                       90975 non-null  object
     3   State                         90975 non-null  object
     4   ZIP code                      90975 non-null  object
     5   Submitted via                 90975 non-null  object
    dtypes: object(6)
    memory usage: 4.2+ MB
    


```python
df.describe(include='all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Consumer complaint narrative</th>
      <th>Company</th>
      <th>State</th>
      <th>ZIP code</th>
      <th>Submitted via</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>90975</td>
      <td>90975</td>
      <td>90975</td>
      <td>90975</td>
      <td>90975</td>
      <td>90975</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>4</td>
      <td>90240</td>
      <td>1497</td>
      <td>62</td>
      <td>5484</td>
      <td>1</td>
    </tr>
    <tr>
      <th>top</th>
      <td>Credit card or prepaid card</td>
      <td>This particular account situation that is late...</td>
      <td>CITIBANK, N.A.</td>
      <td>CA</td>
      <td>None</td>
      <td>Web</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>38294</td>
      <td>125</td>
      <td>6520</td>
      <td>13552</td>
      <td>21892</td>
      <td>90975</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (90975, 6)




```python
df.columns
```




    Index(['Product', 'Consumer complaint narrative', 'Company', 'State', 'ZIP code', 'Submitted via'], dtype='object')




```python

```

## Data Preprocessing

### Drop unwanted features


```python
df.columns
```




    Index(['Product', 'Consumer complaint narrative', 'Company', 'State', 'ZIP code', 'Submitted via'], dtype='object')




```python
df.drop(["Submitted via"],axis=1,inplace=True)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Consumer complaint narrative</th>
      <th>Company</th>
      <th>State</th>
      <th>ZIP code</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Credit card or prepaid card</td>
      <td>I initially in writing to Chase Bank in late X...</td>
      <td>JPMORGAN CHASE &amp; CO.</td>
      <td>CT</td>
      <td>064XX</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mortgage</td>
      <td>My ex husband and myself had a mobile home ( H...</td>
      <td>Ditech Financial LLC</td>
      <td>GA</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Student loan</td>
      <td>I was a student at XXXX XXXX from XX/XX/XXXX-X...</td>
      <td>Navient Solutions, LLC.</td>
      <td>IN</td>
      <td>463XX</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Credit card or prepaid card</td>
      <td>It has come to my attention the CITI group is ...</td>
      <td>CITIBANK, N.A.</td>
      <td>MI</td>
      <td>490XX</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Credit card or prepaid card</td>
      <td>This banks new firearm policies run counter to...</td>
      <td>CITIBANK, N.A.</td>
      <td>MI</td>
      <td>480XX</td>
    </tr>
  </tbody>
</table>
</div>



### Treat Missing Values


```python
df.Company.unique()
```




    array(['JPMORGAN CHASE & CO.', 'Ditech Financial LLC',
           'Navient Solutions, LLC.', ..., 'VIP Mortgage Inc.',
           'Dorough & Dorough, LLC', 'Fidelity Direct Mortgage, LLC'],
          dtype=object)




```python
df.State.unique()
```




    array(['CT', 'GA', 'IN', 'MI', 'FL', 'WA', 'CA', 'VA', 'AZ', 'NY', 'TN',
           'TX', 'IL', 'IA', 'OH', 'MA', 'NV', 'NM', 'MN', 'NJ', 'NC', 'UT',
           'AL', 'LA', 'MD', 'MO', 'AR', 'PA', 'SC', 'OK', 'KS', 'CO', 'DE',
           'DC', 'WI', 'AK', 'ID', 'ME', 'OR', 'NH', 'RI', 'KY', 'HI', 'MS',
           'VT', 'UNITED STATES MINOR OUTLYING ISLANDS', 'SD', 'WV', 'None',
           'ND', 'MT', 'PR', 'NE', 'WY', 'AP', 'GU', 'AE', 'VI', 'AA', 'AS',
           'FM', 'MH'], dtype=object)




```python
df["ZIP code"].unique()
```




    array(['064XX', 'None', '463XX', ..., '32159', '77230', '07042'],
          dtype=object)




```python
df["State"] = df["State"].replace(to_replace="None", value=np.nan)
```


```python
df["ZIP code"] = df["ZIP code"].replace(to_replace="None", value=np.nan)
```


```python
(df.Company == "None").value_counts()
```




    False    90975
    Name: Company, dtype: int64




```python
df.isnull().sum()
```




    Product                             0
    Consumer complaint narrative        0
    Company                             0
    State                             349
    ZIP code                        21892
    dtype: int64




```python
df.dropna(inplace=True)
```


```python
df.isnull().sum()
```




    Product                         0
    Consumer complaint narrative    0
    Company                         0
    State                           0
    ZIP code                        0
    dtype: int64




```python
df.shape
```




    (69069, 5)



### Treat Duplicate Values


```python
df.duplicated(keep='first').sum()
```




    101




```python
#df[df.duplicated(keep=False)] #Check duplicate values
```


```python
#df.drop_duplicates(ignore_index=True, inplace=True)
```


```python

```

### Feature Engineering


```python
df["ZIP code"] = df["ZIP code"].replace(to_replace="X", value="", regex=True)
```


```python
df["ZIP code"]
```




    0        064
    2        463
    3        490
    4        480
    5        331
            ... 
    90968    440
    90969    752
    90970    260
    90971    703
    90974    123
    Name: ZIP code, Length: 69069, dtype: object




```python
df["ZIP code"].unique()
```




    array(['064', '463', '490', ..., '32159', '77230', '07042'], dtype=object)




```python
df["ziplength"] = df["ZIP code"].apply(len)
```


```python
df.ziplength.unique()
```




    array([3, 5], dtype=int64)




```python
df["complength"] = df["Company"].apply(len)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Consumer complaint narrative</th>
      <th>Company</th>
      <th>State</th>
      <th>ZIP code</th>
      <th>ziplength</th>
      <th>complength</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Credit card or prepaid card</td>
      <td>I initially in writing to Chase Bank in late X...</td>
      <td>JPMORGAN CHASE &amp; CO.</td>
      <td>CT</td>
      <td>064</td>
      <td>3</td>
      <td>20</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Student loan</td>
      <td>I was a student at XXXX XXXX from XX/XX/XXXX-X...</td>
      <td>Navient Solutions, LLC.</td>
      <td>IN</td>
      <td>463</td>
      <td>3</td>
      <td>23</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Credit card or prepaid card</td>
      <td>It has come to my attention the CITI group is ...</td>
      <td>CITIBANK, N.A.</td>
      <td>MI</td>
      <td>490</td>
      <td>3</td>
      <td>14</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Credit card or prepaid card</td>
      <td>This banks new firearm policies run counter to...</td>
      <td>CITIBANK, N.A.</td>
      <td>MI</td>
      <td>480</td>
      <td>3</td>
      <td>14</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Credit card or prepaid card</td>
      <td>I only use my walmart store card to keep from ...</td>
      <td>SYNCHRONY FINANCIAL</td>
      <td>FL</td>
      <td>331</td>
      <td>3</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
df["custlength"] = df["Consumer complaint narrative"].apply(len)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Consumer complaint narrative</th>
      <th>Company</th>
      <th>State</th>
      <th>ZIP code</th>
      <th>ziplength</th>
      <th>complength</th>
      <th>custlength</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Credit card or prepaid card</td>
      <td>I initially in writing to Chase Bank in late X...</td>
      <td>JPMORGAN CHASE &amp; CO.</td>
      <td>CT</td>
      <td>064</td>
      <td>3</td>
      <td>20</td>
      <td>813</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Student loan</td>
      <td>I was a student at XXXX XXXX from XX/XX/XXXX-X...</td>
      <td>Navient Solutions, LLC.</td>
      <td>IN</td>
      <td>463</td>
      <td>3</td>
      <td>23</td>
      <td>966</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Credit card or prepaid card</td>
      <td>It has come to my attention the CITI group is ...</td>
      <td>CITIBANK, N.A.</td>
      <td>MI</td>
      <td>490</td>
      <td>3</td>
      <td>14</td>
      <td>520</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Credit card or prepaid card</td>
      <td>This banks new firearm policies run counter to...</td>
      <td>CITIBANK, N.A.</td>
      <td>MI</td>
      <td>480</td>
      <td>3</td>
      <td>14</td>
      <td>506</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Credit card or prepaid card</td>
      <td>I only use my walmart store card to keep from ...</td>
      <td>SYNCHRONY FINANCIAL</td>
      <td>FL</td>
      <td>331</td>
      <td>3</td>
      <td>19</td>
      <td>948</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.columns
```




    Index(['Product', 'Consumer complaint narrative', 'Company', 'State', 'ZIP code', 'ziplength', 'complength', 'custlength'], dtype='object')




```python
df.drop(['Consumer complaint narrative', 'Company', 'State', 'ZIP code'],axis=1,inplace=True)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>ziplength</th>
      <th>complength</th>
      <th>custlength</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Credit card or prepaid card</td>
      <td>3</td>
      <td>20</td>
      <td>813</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Student loan</td>
      <td>3</td>
      <td>23</td>
      <td>966</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Credit card or prepaid card</td>
      <td>3</td>
      <td>14</td>
      <td>520</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Credit card or prepaid card</td>
      <td>3</td>
      <td>14</td>
      <td>506</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Credit card or prepaid card</td>
      <td>3</td>
      <td>19</td>
      <td>948</td>
    </tr>
  </tbody>
</table>
</div>




```python
encoder = LabelEncoder()
```


```python
df["Product"] = encoder.fit_transform(df["Product"])
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>ziplength</th>
      <th>complength</th>
      <th>custlength</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>3</td>
      <td>20</td>
      <td>813</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>3</td>
      <td>23</td>
      <td>966</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>3</td>
      <td>14</td>
      <td>520</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>3</td>
      <td>14</td>
      <td>506</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0</td>
      <td>3</td>
      <td>19</td>
      <td>948</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>90968</th>
      <td>0</td>
      <td>3</td>
      <td>27</td>
      <td>628</td>
    </tr>
    <tr>
      <th>90969</th>
      <td>0</td>
      <td>3</td>
      <td>22</td>
      <td>758</td>
    </tr>
    <tr>
      <th>90970</th>
      <td>0</td>
      <td>3</td>
      <td>20</td>
      <td>1455</td>
    </tr>
    <tr>
      <th>90971</th>
      <td>3</td>
      <td>3</td>
      <td>24</td>
      <td>939</td>
    </tr>
    <tr>
      <th>90974</th>
      <td>1</td>
      <td>3</td>
      <td>30</td>
      <td>61</td>
    </tr>
  </tbody>
</table>
<p>69069 rows × 4 columns</p>
</div>




```python
df.reset_index(inplace=True, drop=True)
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>ziplength</th>
      <th>complength</th>
      <th>custlength</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>3</td>
      <td>20</td>
      <td>813</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>3</td>
      <td>23</td>
      <td>966</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>3</td>
      <td>14</td>
      <td>520</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>3</td>
      <td>14</td>
      <td>506</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>3</td>
      <td>19</td>
      <td>948</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>69064</th>
      <td>0</td>
      <td>3</td>
      <td>27</td>
      <td>628</td>
    </tr>
    <tr>
      <th>69065</th>
      <td>0</td>
      <td>3</td>
      <td>22</td>
      <td>758</td>
    </tr>
    <tr>
      <th>69066</th>
      <td>0</td>
      <td>3</td>
      <td>20</td>
      <td>1455</td>
    </tr>
    <tr>
      <th>69067</th>
      <td>3</td>
      <td>3</td>
      <td>24</td>
      <td>939</td>
    </tr>
    <tr>
      <th>69068</th>
      <td>1</td>
      <td>3</td>
      <td>30</td>
      <td>61</td>
    </tr>
  </tbody>
</table>
<p>69069 rows × 4 columns</p>
</div>




```python
df.columns
```




    Index(['Product', 'ziplength', 'complength', 'custlength'], dtype='object')




```python
df2 = df[['ziplength', 'complength', 'custlength','Product']]
```


```python
df2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ziplength</th>
      <th>complength</th>
      <th>custlength</th>
      <th>Product</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3</td>
      <td>20</td>
      <td>813</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>23</td>
      <td>966</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>14</td>
      <td>520</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>14</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>19</td>
      <td>948</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



### Create and save processed dataset


```python
#df2.to_csv("train.csv",index=False)
```


```python
df2.shape
```




    (69069, 4)



### Train Test Split


```python
X = df2.iloc[:,:3]
y = df2.iloc[:,3]
```

### Treat Imbalance Data


```python
#y.value_counts()
```


```python
#ros = RandomOverSampler(sampling_strategy='all',random_state=0)
```


```python
#new_X, new_y = ros.fit_resample(X, y)
```


```python
#new_y[].value_counts()
```


```python
#new_X
```

### Train Test Split Cont'd


```python
X.values, y.values
```




    (array([[   3,   20,  813],
            [   3,   23,  966],
            [   3,   14,  520],
            ...,
            [   3,   20, 1455],
            [   3,   24,  939],
            [   3,   30,   61]], dtype=int64),
     array([0, 2, 0, ..., 0, 3, 1]))




```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
```


```python
X_train.shape, X_test.shape, y_train.shape, y_test.shape
```




    ((55255, 3), (13814, 3), (55255,), (13814,))



## Feature Scaling


```python
X_train
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ziplength</th>
      <th>complength</th>
      <th>custlength</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>65086</th>
      <td>3</td>
      <td>20</td>
      <td>2479</td>
    </tr>
    <tr>
      <th>43364</th>
      <td>3</td>
      <td>27</td>
      <td>1519</td>
    </tr>
    <tr>
      <th>64246</th>
      <td>3</td>
      <td>33</td>
      <td>1497</td>
    </tr>
    <tr>
      <th>17765</th>
      <td>3</td>
      <td>32</td>
      <td>2655</td>
    </tr>
    <tr>
      <th>38787</th>
      <td>3</td>
      <td>37</td>
      <td>1474</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>21243</th>
      <td>3</td>
      <td>33</td>
      <td>655</td>
    </tr>
    <tr>
      <th>45891</th>
      <td>3</td>
      <td>38</td>
      <td>926</td>
    </tr>
    <tr>
      <th>42613</th>
      <td>3</td>
      <td>27</td>
      <td>761</td>
    </tr>
    <tr>
      <th>43567</th>
      <td>3</td>
      <td>30</td>
      <td>2889</td>
    </tr>
    <tr>
      <th>68268</th>
      <td>3</td>
      <td>21</td>
      <td>683</td>
    </tr>
  </tbody>
</table>
<p>55255 rows × 3 columns</p>
</div>




```python
scaler = StandardScaler()
```


```python
X_train_scaled = scaler.fit_transform(X_train)
```


```python
X_test_scaled = scaler.transform(X_test)
```


```python
X_train_scaled
```




    array([[-0.37408082, -0.41375478,  0.59715483],
           [-0.37408082,  0.44333529,  0.02127045],
           [-0.37408082,  1.17798391,  0.00807309],
           ...,
           [-0.37408082,  0.44333529, -0.43343826],
           [-0.37408082,  0.8106596 ,  0.84310545],
           [-0.37408082, -0.29131334, -0.48022887]])




```python
X_test_scaled
```




    array([[-0.37408082,  0.44333529, -0.67578961],
           [-0.37408082,  1.17798391,  0.30081432],
           [-0.37408082, -0.41375478, -0.61460189],
           ...,
           [-0.37408082,  1.17798391, -0.37465007],
           [-0.37408082,  0.07601097, -0.35365428],
           [ 2.67321914, -0.29131334,  3.59175361]])



### Model Training

## Using Classification Models


```python
classi_model = GradientBoostingClassifier()
```


```python
classi_model.fit(X_train_scaled,y_train)
```




    GradientBoostingClassifier()




```python
y_pred = classi_model.predict(X_test_scaled)
```


```python
y_pred
```




    array([0, 0, 0, ..., 0, 0, 1])



### Model Evaluation


```python
cm = confusion_matrix(y_test,y_pred)
cm
```




    array([[4392, 1174,  112,  168],
           [1786, 2724,   89,  122],
           [ 247,  174, 1340,   36],
           [ 441,  450,  115,  444]], dtype=int64)




```python
fig , ax = plt.subplots(figsize=(10,5))
sns.heatmap(cm, annot=True,fmt='.4g',linewidths=2, cmap='viridis')
plt.ylabel('True label')
plt.xlabel('Predicted label')
plt.show()
```


    
![png](output_86_0.png)
    



```python
print(classification_report(y_test,y_pred))
```

                  precision    recall  f1-score   support
    
               0       0.64      0.75      0.69      5846
               1       0.60      0.58      0.59      4721
               2       0.81      0.75      0.78      1797
               3       0.58      0.31      0.40      1450
    
        accuracy                           0.64     13814
       macro avg       0.66      0.60      0.61     13814
    weighted avg       0.64      0.64      0.64     13814
    
    

### Plot Feature Importances


```python
classi_model.feature_importances_
```




    array([0.00299503, 0.94943115, 0.04757383])




```python
feat_importances = pd.Series(classi_model.feature_importances_, index=X.columns)
```


```python
feat_importances
```




    ziplength    0.00
    complength   0.95
    custlength   0.05
    dtype: float64




```python
feat_importances.nlargest(10).plot(kind='barh', figsize=(10,10))
plt.title('Feature Importances')
plt.show()
```


    
![png](output_92_0.png)
    


#### Python code done by Dennis


```python

```
