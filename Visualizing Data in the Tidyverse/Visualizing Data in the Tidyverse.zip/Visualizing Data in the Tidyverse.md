In this course, we have learned the importance of data visualization and how to leverage packages in the Tidyverse for data visualization in R. This project will give you the opportunity to practice those skills in greater depth. 

The overall goal is to explore the nutrition of entree items and the sales of fast food restaurants in 2018. Your task is to reconstruct the a set of plots, all of which were constructed using packages in the Tidyverse or packages that integrate with the Tidyverse. 

### Import Libraries


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
import datetime
from datetime import datetime, timedelta
import scipy.stats
import pandas_profiling
from pandas_profiling import ProfileReport


%matplotlib inline
#sets the default autosave frequency in seconds
%autosave 60 
sns.set_style('dark')
sns.set(font_scale=1.2)

plt.rc('axes', titlesize=9)
plt.rc('axes', labelsize=14)
plt.rc('xtick', labelsize=12)
plt.rc('ytick', labelsize=12)

import warnings
warnings.filterwarnings('ignore')

pd.set_option('display.max_columns',None)
#pd.set_option('display.max_rows',None)
pd.set_option('display.width', 1000)
pd.option_context('float_format','{:.2f}'.format)

np.random.seed(0)
np.set_printoptions(suppress=True)
```



    Autosaving every 60 seconds
    


```python
df_fastfood = pd.read_csv("data_fastfood_sales.csv")
```


```python
df_fastfood
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>average_sales</th>
      <th>us_sales</th>
      <th>num_company_stores</th>
      <th>num_franchised_stores</th>
      <th>unit_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Subway</td>
      <td>416.86</td>
      <td>10800.00</td>
      <td>0</td>
      <td>25908</td>
      <td>25908</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>2670.32</td>
      <td>37480.67</td>
      <td>842</td>
      <td>13194</td>
      <td>14036</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Starbucks</td>
      <td>945.27</td>
      <td>13167.61</td>
      <td>8222</td>
      <td>5708</td>
      <td>13930</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Dunkin Donuts</td>
      <td>733.13</td>
      <td>9192.00</td>
      <td>0</td>
      <td>12538</td>
      <td>12538</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Pizza Hut</td>
      <td>900.00</td>
      <td>5510.84</td>
      <td>96</td>
      <td>7426</td>
      <td>7522</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Burger King</td>
      <td>1387.81</td>
      <td>10028.32</td>
      <td>50</td>
      <td>7196</td>
      <td>7266</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Taco Bell</td>
      <td>1500.00</td>
      <td>9790.15</td>
      <td>647</td>
      <td>5799</td>
      <td>6446</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Wendys</td>
      <td>1610.00</td>
      <td>9288.09</td>
      <td>337</td>
      <td>5432</td>
      <td>5759</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Dominos</td>
      <td>1000.00</td>
      <td>5900.00</td>
      <td>392</td>
      <td>5195</td>
      <td>5587</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Little Caesars</td>
      <td>815.00</td>
      <td>3530.58</td>
      <td>535</td>
      <td>3797</td>
      <td>4332</td>
    </tr>
    <tr>
      <th>10</th>
      <td>KFC</td>
      <td>1200.00</td>
      <td>4417.05</td>
      <td>54</td>
      <td>4055</td>
      <td>4109</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Sonic</td>
      <td>1250.00</td>
      <td>4408.16</td>
      <td>228</td>
      <td>3365</td>
      <td>3593</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Arbys</td>
      <td>1130.00</td>
      <td>3634.00</td>
      <td>1075</td>
      <td>2340</td>
      <td>3415</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Papa Johns</td>
      <td>968.45</td>
      <td>3209.30</td>
      <td>708</td>
      <td>2606</td>
      <td>3314</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Jimmy Johns</td>
      <td>796.97</td>
      <td>2139.62</td>
      <td>55</td>
      <td>2700</td>
      <td>2755</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Baskin-Robbins</td>
      <td>360.72</td>
      <td>606.00</td>
      <td>0</td>
      <td>2560</td>
      <td>2560</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Chipotle</td>
      <td>1940.00</td>
      <td>4476.41</td>
      <td>2371</td>
      <td>0</td>
      <td>2371</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Jack in the Box</td>
      <td>1543.00</td>
      <td>3469.17</td>
      <td>276</td>
      <td>1975</td>
      <td>2251</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Popeyes</td>
      <td>1440.19</td>
      <td>3213.06</td>
      <td>53</td>
      <td>2178</td>
      <td>2231</td>
    </tr>
  </tbody>
</table>
</div>



## Exploratory Data Analysis


```python
df_fastfood.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 19 entries, 0 to 18
    Data columns (total 6 columns):
     #   Column                 Non-Null Count  Dtype  
    ---  ------                 --------------  -----  
     0   restaurant             19 non-null     object 
     1   average_sales          19 non-null     float64
     2   us_sales               19 non-null     float64
     3   num_company_stores     19 non-null     int64  
     4   num_franchised_stores  19 non-null     int64  
     5   unit_count             19 non-null     int64  
    dtypes: float64(2), int64(3), object(1)
    memory usage: 1.0+ KB
    


```python
df_fastfood.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>average_sales</th>
      <th>us_sales</th>
      <th>num_company_stores</th>
      <th>num_franchised_stores</th>
      <th>unit_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>19.000000</td>
      <td>19.000000</td>
      <td>19.000000</td>
      <td>19.000000</td>
      <td>19.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1189.880000</td>
      <td>7592.685789</td>
      <td>839.000000</td>
      <td>5998.526316</td>
      <td>6838.052632</td>
    </tr>
    <tr>
      <th>std</th>
      <td>541.522319</td>
      <td>8007.316428</td>
      <td>1875.795713</td>
      <td>5894.507390</td>
      <td>5997.132653</td>
    </tr>
    <tr>
      <th>min</th>
      <td>360.720000</td>
      <td>606.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>2231.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>857.500000</td>
      <td>3499.875000</td>
      <td>53.500000</td>
      <td>2583.000000</td>
      <td>3034.500000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1130.000000</td>
      <td>4476.410000</td>
      <td>276.000000</td>
      <td>4055.000000</td>
      <td>4332.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>1470.095000</td>
      <td>9539.120000</td>
      <td>677.500000</td>
      <td>6497.500000</td>
      <td>7394.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2670.320000</td>
      <td>37480.670000</td>
      <td>8222.000000</td>
      <td>25908.000000</td>
      <td>25908.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_fastfood.columns
```




    Index(['restaurant', 'average_sales', 'us_sales', 'num_company_stores', 'num_franchised_stores', 'unit_count'], dtype='object')



## Data Visualization

### Problem 1


```python
df_fastfood["log_sales"] = np.log10(df_fastfood["us_sales"])
```


```python
df_fastfood["log_stores"] = np.log10(df_fastfood["unit_count"])
```


```python
df_fastfood
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>average_sales</th>
      <th>us_sales</th>
      <th>num_company_stores</th>
      <th>num_franchised_stores</th>
      <th>unit_count</th>
      <th>log_sales</th>
      <th>log_stores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Subway</td>
      <td>416.86</td>
      <td>10800.00</td>
      <td>0</td>
      <td>25908</td>
      <td>25908</td>
      <td>4.033424</td>
      <td>4.413434</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>2670.32</td>
      <td>37480.67</td>
      <td>842</td>
      <td>13194</td>
      <td>14036</td>
      <td>4.573807</td>
      <td>4.147243</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Starbucks</td>
      <td>945.27</td>
      <td>13167.61</td>
      <td>8222</td>
      <td>5708</td>
      <td>13930</td>
      <td>4.119507</td>
      <td>4.143951</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Dunkin Donuts</td>
      <td>733.13</td>
      <td>9192.00</td>
      <td>0</td>
      <td>12538</td>
      <td>12538</td>
      <td>3.963410</td>
      <td>4.098228</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Pizza Hut</td>
      <td>900.00</td>
      <td>5510.84</td>
      <td>96</td>
      <td>7426</td>
      <td>7522</td>
      <td>3.741218</td>
      <td>3.876333</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Burger King</td>
      <td>1387.81</td>
      <td>10028.32</td>
      <td>50</td>
      <td>7196</td>
      <td>7266</td>
      <td>4.001228</td>
      <td>3.861295</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Taco Bell</td>
      <td>1500.00</td>
      <td>9790.15</td>
      <td>647</td>
      <td>5799</td>
      <td>6446</td>
      <td>3.990789</td>
      <td>3.809290</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Wendys</td>
      <td>1610.00</td>
      <td>9288.09</td>
      <td>337</td>
      <td>5432</td>
      <td>5759</td>
      <td>3.967926</td>
      <td>3.760347</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Dominos</td>
      <td>1000.00</td>
      <td>5900.00</td>
      <td>392</td>
      <td>5195</td>
      <td>5587</td>
      <td>3.770852</td>
      <td>3.747179</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Little Caesars</td>
      <td>815.00</td>
      <td>3530.58</td>
      <td>535</td>
      <td>3797</td>
      <td>4332</td>
      <td>3.547846</td>
      <td>3.636688</td>
    </tr>
    <tr>
      <th>10</th>
      <td>KFC</td>
      <td>1200.00</td>
      <td>4417.05</td>
      <td>54</td>
      <td>4055</td>
      <td>4109</td>
      <td>3.645132</td>
      <td>3.613736</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Sonic</td>
      <td>1250.00</td>
      <td>4408.16</td>
      <td>228</td>
      <td>3365</td>
      <td>3593</td>
      <td>3.644257</td>
      <td>3.555457</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Arbys</td>
      <td>1130.00</td>
      <td>3634.00</td>
      <td>1075</td>
      <td>2340</td>
      <td>3415</td>
      <td>3.560385</td>
      <td>3.533391</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Papa Johns</td>
      <td>968.45</td>
      <td>3209.30</td>
      <td>708</td>
      <td>2606</td>
      <td>3314</td>
      <td>3.506410</td>
      <td>3.520353</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Jimmy Johns</td>
      <td>796.97</td>
      <td>2139.62</td>
      <td>55</td>
      <td>2700</td>
      <td>2755</td>
      <td>3.330337</td>
      <td>3.440122</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Baskin-Robbins</td>
      <td>360.72</td>
      <td>606.00</td>
      <td>0</td>
      <td>2560</td>
      <td>2560</td>
      <td>2.782473</td>
      <td>3.408240</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Chipotle</td>
      <td>1940.00</td>
      <td>4476.41</td>
      <td>2371</td>
      <td>0</td>
      <td>2371</td>
      <td>3.650930</td>
      <td>3.374932</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Jack in the Box</td>
      <td>1543.00</td>
      <td>3469.17</td>
      <td>276</td>
      <td>1975</td>
      <td>2251</td>
      <td>3.540226</td>
      <td>3.352375</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Popeyes</td>
      <td>1440.19</td>
      <td>3213.06</td>
      <td>53</td>
      <td>2178</td>
      <td>2231</td>
      <td>3.506919</td>
      <td>3.348500</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(20,20))
sns.scatterplot(x="log_sales", y="log_stores", data=df_fastfood, hue="restaurant", ci=None, s=100)
plt.xlabel("US Sales in Millions")
plt.ylabel("Total number of stores")
plt.show()
```


    
![png](output_15_0.png)
    


### Problem 2


```python
df_sales = pd.read_csv("data_fastfood_sales.csv")
```


```python
df_sales
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>average_sales</th>
      <th>us_sales</th>
      <th>num_company_stores</th>
      <th>num_franchised_stores</th>
      <th>unit_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Subway</td>
      <td>416.86</td>
      <td>10800.00</td>
      <td>0</td>
      <td>25908</td>
      <td>25908</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>2670.32</td>
      <td>37480.67</td>
      <td>842</td>
      <td>13194</td>
      <td>14036</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Starbucks</td>
      <td>945.27</td>
      <td>13167.61</td>
      <td>8222</td>
      <td>5708</td>
      <td>13930</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Dunkin Donuts</td>
      <td>733.13</td>
      <td>9192.00</td>
      <td>0</td>
      <td>12538</td>
      <td>12538</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Pizza Hut</td>
      <td>900.00</td>
      <td>5510.84</td>
      <td>96</td>
      <td>7426</td>
      <td>7522</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Burger King</td>
      <td>1387.81</td>
      <td>10028.32</td>
      <td>50</td>
      <td>7196</td>
      <td>7266</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Taco Bell</td>
      <td>1500.00</td>
      <td>9790.15</td>
      <td>647</td>
      <td>5799</td>
      <td>6446</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Wendys</td>
      <td>1610.00</td>
      <td>9288.09</td>
      <td>337</td>
      <td>5432</td>
      <td>5759</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Dominos</td>
      <td>1000.00</td>
      <td>5900.00</td>
      <td>392</td>
      <td>5195</td>
      <td>5587</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Little Caesars</td>
      <td>815.00</td>
      <td>3530.58</td>
      <td>535</td>
      <td>3797</td>
      <td>4332</td>
    </tr>
    <tr>
      <th>10</th>
      <td>KFC</td>
      <td>1200.00</td>
      <td>4417.05</td>
      <td>54</td>
      <td>4055</td>
      <td>4109</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Sonic</td>
      <td>1250.00</td>
      <td>4408.16</td>
      <td>228</td>
      <td>3365</td>
      <td>3593</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Arbys</td>
      <td>1130.00</td>
      <td>3634.00</td>
      <td>1075</td>
      <td>2340</td>
      <td>3415</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Papa Johns</td>
      <td>968.45</td>
      <td>3209.30</td>
      <td>708</td>
      <td>2606</td>
      <td>3314</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Jimmy Johns</td>
      <td>796.97</td>
      <td>2139.62</td>
      <td>55</td>
      <td>2700</td>
      <td>2755</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Baskin-Robbins</td>
      <td>360.72</td>
      <td>606.00</td>
      <td>0</td>
      <td>2560</td>
      <td>2560</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Chipotle</td>
      <td>1940.00</td>
      <td>4476.41</td>
      <td>2371</td>
      <td>0</td>
      <td>2371</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Jack in the Box</td>
      <td>1543.00</td>
      <td>3469.17</td>
      <td>276</td>
      <td>1975</td>
      <td>2251</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Popeyes</td>
      <td>1440.19</td>
      <td>3213.06</td>
      <td>53</td>
      <td>2178</td>
      <td>2231</td>
    </tr>
  </tbody>
</table>
</div>




```python
df2 = df_sales.sort_values(by="average_sales", ascending=False)
df2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>average_sales</th>
      <th>us_sales</th>
      <th>num_company_stores</th>
      <th>num_franchised_stores</th>
      <th>unit_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>2670.32</td>
      <td>37480.67</td>
      <td>842</td>
      <td>13194</td>
      <td>14036</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Chipotle</td>
      <td>1940.00</td>
      <td>4476.41</td>
      <td>2371</td>
      <td>0</td>
      <td>2371</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Wendys</td>
      <td>1610.00</td>
      <td>9288.09</td>
      <td>337</td>
      <td>5432</td>
      <td>5759</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Jack in the Box</td>
      <td>1543.00</td>
      <td>3469.17</td>
      <td>276</td>
      <td>1975</td>
      <td>2251</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Taco Bell</td>
      <td>1500.00</td>
      <td>9790.15</td>
      <td>647</td>
      <td>5799</td>
      <td>6446</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Popeyes</td>
      <td>1440.19</td>
      <td>3213.06</td>
      <td>53</td>
      <td>2178</td>
      <td>2231</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Burger King</td>
      <td>1387.81</td>
      <td>10028.32</td>
      <td>50</td>
      <td>7196</td>
      <td>7266</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Sonic</td>
      <td>1250.00</td>
      <td>4408.16</td>
      <td>228</td>
      <td>3365</td>
      <td>3593</td>
    </tr>
    <tr>
      <th>10</th>
      <td>KFC</td>
      <td>1200.00</td>
      <td>4417.05</td>
      <td>54</td>
      <td>4055</td>
      <td>4109</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Arbys</td>
      <td>1130.00</td>
      <td>3634.00</td>
      <td>1075</td>
      <td>2340</td>
      <td>3415</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Dominos</td>
      <td>1000.00</td>
      <td>5900.00</td>
      <td>392</td>
      <td>5195</td>
      <td>5587</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Papa Johns</td>
      <td>968.45</td>
      <td>3209.30</td>
      <td>708</td>
      <td>2606</td>
      <td>3314</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Starbucks</td>
      <td>945.27</td>
      <td>13167.61</td>
      <td>8222</td>
      <td>5708</td>
      <td>13930</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Pizza Hut</td>
      <td>900.00</td>
      <td>5510.84</td>
      <td>96</td>
      <td>7426</td>
      <td>7522</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Little Caesars</td>
      <td>815.00</td>
      <td>3530.58</td>
      <td>535</td>
      <td>3797</td>
      <td>4332</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Jimmy Johns</td>
      <td>796.97</td>
      <td>2139.62</td>
      <td>55</td>
      <td>2700</td>
      <td>2755</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Dunkin Donuts</td>
      <td>733.13</td>
      <td>9192.00</td>
      <td>0</td>
      <td>12538</td>
      <td>12538</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Subway</td>
      <td>416.86</td>
      <td>10800.00</td>
      <td>0</td>
      <td>25908</td>
      <td>25908</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Baskin-Robbins</td>
      <td>360.72</td>
      <td>606.00</td>
      <td>0</td>
      <td>2560</td>
      <td>2560</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(20,20))
sns.barplot(x="average_sales", y="restaurant", data=df2, ci=None)
plt.xlabel("Average Sales per unit store")
plt.ylabel("Restaurants")
plt.show()
```


    
![png](output_20_0.png)
    


### Problem 3


```python
df_calories = pd.read_csv("data_fastfood_calories.csv")
```


```python
df_calories
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>item</th>
      <th>calories</th>
      <th>cal_fat</th>
      <th>total_fat</th>
      <th>sat_fat</th>
      <th>trans_fat</th>
      <th>cholesterol</th>
      <th>sodium</th>
      <th>total_carb</th>
      <th>fiber</th>
      <th>sugar</th>
      <th>protein</th>
      <th>vit_a</th>
      <th>vit_c</th>
      <th>calcium</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Mcdonalds</td>
      <td>Artisan Grilled Chicken Sandwich</td>
      <td>380</td>
      <td>60</td>
      <td>7</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>95</td>
      <td>1110</td>
      <td>44</td>
      <td>3.0</td>
      <td>11</td>
      <td>37.0</td>
      <td>4.0</td>
      <td>20.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>Single Bacon Smokehouse Burger</td>
      <td>840</td>
      <td>410</td>
      <td>45</td>
      <td>17.0</td>
      <td>1.5</td>
      <td>130</td>
      <td>1580</td>
      <td>62</td>
      <td>2.0</td>
      <td>18</td>
      <td>46.0</td>
      <td>6.0</td>
      <td>20.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mcdonalds</td>
      <td>Double Bacon Smokehouse Burger</td>
      <td>1130</td>
      <td>600</td>
      <td>67</td>
      <td>27.0</td>
      <td>3.0</td>
      <td>220</td>
      <td>1920</td>
      <td>63</td>
      <td>3.0</td>
      <td>18</td>
      <td>70.0</td>
      <td>10.0</td>
      <td>20.0</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mcdonalds</td>
      <td>Grilled Bacon Smokehouse Chicken Sandwich</td>
      <td>750</td>
      <td>280</td>
      <td>31</td>
      <td>10.0</td>
      <td>0.5</td>
      <td>155</td>
      <td>1940</td>
      <td>62</td>
      <td>2.0</td>
      <td>18</td>
      <td>55.0</td>
      <td>6.0</td>
      <td>25.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Mcdonalds</td>
      <td>Crispy Bacon Smokehouse Chicken Sandwich</td>
      <td>920</td>
      <td>410</td>
      <td>45</td>
      <td>12.0</td>
      <td>0.5</td>
      <td>120</td>
      <td>1980</td>
      <td>81</td>
      <td>4.0</td>
      <td>18</td>
      <td>46.0</td>
      <td>6.0</td>
      <td>20.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>510</th>
      <td>Taco Bell</td>
      <td>Spicy Triple Double Crunchwrap</td>
      <td>780</td>
      <td>340</td>
      <td>38</td>
      <td>10.0</td>
      <td>0.5</td>
      <td>50</td>
      <td>1850</td>
      <td>87</td>
      <td>9.0</td>
      <td>8</td>
      <td>23.0</td>
      <td>20.0</td>
      <td>10.0</td>
      <td>25.0</td>
    </tr>
    <tr>
      <th>511</th>
      <td>Taco Bell</td>
      <td>Express Taco Salad w/ Chips</td>
      <td>580</td>
      <td>260</td>
      <td>29</td>
      <td>9.0</td>
      <td>1.0</td>
      <td>60</td>
      <td>1270</td>
      <td>59</td>
      <td>8.0</td>
      <td>7</td>
      <td>23.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>512</th>
      <td>Taco Bell</td>
      <td>Fiesta Taco Salad-Beef</td>
      <td>780</td>
      <td>380</td>
      <td>42</td>
      <td>10.0</td>
      <td>1.0</td>
      <td>60</td>
      <td>1340</td>
      <td>74</td>
      <td>11.0</td>
      <td>7</td>
      <td>26.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>513</th>
      <td>Taco Bell</td>
      <td>Fiesta Taco Salad-Chicken</td>
      <td>720</td>
      <td>320</td>
      <td>35</td>
      <td>7.0</td>
      <td>0.0</td>
      <td>70</td>
      <td>1260</td>
      <td>70</td>
      <td>8.0</td>
      <td>8</td>
      <td>32.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>514</th>
      <td>Taco Bell</td>
      <td>Fiesta Taco Salad-Steak</td>
      <td>720</td>
      <td>320</td>
      <td>36</td>
      <td>8.0</td>
      <td>1.0</td>
      <td>55</td>
      <td>1340</td>
      <td>70</td>
      <td>8.0</td>
      <td>8</td>
      <td>28.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>515 rows × 16 columns</p>
</div>




```python
plt.figure(figsize=(40,20))
sns.catplot(x='calories', y = 'sodium', col = 'restaurant', col_wrap=3,
            kind='strip', data=df_calories, height = 5, aspect = 1, s=10)
plt.xticks(rotation=90)
plt.show()
```


    <Figure size 2880x1440 with 0 Axes>



    
![png](output_24_1.png)
    


### Problem 4


```python
df_calories.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>item</th>
      <th>calories</th>
      <th>cal_fat</th>
      <th>total_fat</th>
      <th>sat_fat</th>
      <th>trans_fat</th>
      <th>cholesterol</th>
      <th>sodium</th>
      <th>total_carb</th>
      <th>fiber</th>
      <th>sugar</th>
      <th>protein</th>
      <th>vit_a</th>
      <th>vit_c</th>
      <th>calcium</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Mcdonalds</td>
      <td>Artisan Grilled Chicken Sandwich</td>
      <td>380</td>
      <td>60</td>
      <td>7</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>95</td>
      <td>1110</td>
      <td>44</td>
      <td>3.0</td>
      <td>11</td>
      <td>37.0</td>
      <td>4.0</td>
      <td>20.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>Single Bacon Smokehouse Burger</td>
      <td>840</td>
      <td>410</td>
      <td>45</td>
      <td>17.0</td>
      <td>1.5</td>
      <td>130</td>
      <td>1580</td>
      <td>62</td>
      <td>2.0</td>
      <td>18</td>
      <td>46.0</td>
      <td>6.0</td>
      <td>20.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mcdonalds</td>
      <td>Double Bacon Smokehouse Burger</td>
      <td>1130</td>
      <td>600</td>
      <td>67</td>
      <td>27.0</td>
      <td>3.0</td>
      <td>220</td>
      <td>1920</td>
      <td>63</td>
      <td>3.0</td>
      <td>18</td>
      <td>70.0</td>
      <td>10.0</td>
      <td>20.0</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mcdonalds</td>
      <td>Grilled Bacon Smokehouse Chicken Sandwich</td>
      <td>750</td>
      <td>280</td>
      <td>31</td>
      <td>10.0</td>
      <td>0.5</td>
      <td>155</td>
      <td>1940</td>
      <td>62</td>
      <td>2.0</td>
      <td>18</td>
      <td>55.0</td>
      <td>6.0</td>
      <td>25.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Mcdonalds</td>
      <td>Crispy Bacon Smokehouse Chicken Sandwich</td>
      <td>920</td>
      <td>410</td>
      <td>45</td>
      <td>12.0</td>
      <td>0.5</td>
      <td>120</td>
      <td>1980</td>
      <td>81</td>
      <td>4.0</td>
      <td>18</td>
      <td>46.0</td>
      <td>6.0</td>
      <td>20.0</td>
      <td>20.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_calories["is_salad"] = df_calories["item"].str.contains("Salad")
```


```python
df_calories
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>item</th>
      <th>calories</th>
      <th>cal_fat</th>
      <th>total_fat</th>
      <th>sat_fat</th>
      <th>trans_fat</th>
      <th>cholesterol</th>
      <th>sodium</th>
      <th>total_carb</th>
      <th>fiber</th>
      <th>sugar</th>
      <th>protein</th>
      <th>vit_a</th>
      <th>vit_c</th>
      <th>calcium</th>
      <th>is_salad</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Mcdonalds</td>
      <td>Artisan Grilled Chicken Sandwich</td>
      <td>380</td>
      <td>60</td>
      <td>7</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>95</td>
      <td>1110</td>
      <td>44</td>
      <td>3.0</td>
      <td>11</td>
      <td>37.0</td>
      <td>4.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>Single Bacon Smokehouse Burger</td>
      <td>840</td>
      <td>410</td>
      <td>45</td>
      <td>17.0</td>
      <td>1.5</td>
      <td>130</td>
      <td>1580</td>
      <td>62</td>
      <td>2.0</td>
      <td>18</td>
      <td>46.0</td>
      <td>6.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mcdonalds</td>
      <td>Double Bacon Smokehouse Burger</td>
      <td>1130</td>
      <td>600</td>
      <td>67</td>
      <td>27.0</td>
      <td>3.0</td>
      <td>220</td>
      <td>1920</td>
      <td>63</td>
      <td>3.0</td>
      <td>18</td>
      <td>70.0</td>
      <td>10.0</td>
      <td>20.0</td>
      <td>50.0</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mcdonalds</td>
      <td>Grilled Bacon Smokehouse Chicken Sandwich</td>
      <td>750</td>
      <td>280</td>
      <td>31</td>
      <td>10.0</td>
      <td>0.5</td>
      <td>155</td>
      <td>1940</td>
      <td>62</td>
      <td>2.0</td>
      <td>18</td>
      <td>55.0</td>
      <td>6.0</td>
      <td>25.0</td>
      <td>20.0</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Mcdonalds</td>
      <td>Crispy Bacon Smokehouse Chicken Sandwich</td>
      <td>920</td>
      <td>410</td>
      <td>45</td>
      <td>12.0</td>
      <td>0.5</td>
      <td>120</td>
      <td>1980</td>
      <td>81</td>
      <td>4.0</td>
      <td>18</td>
      <td>46.0</td>
      <td>6.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>510</th>
      <td>Taco Bell</td>
      <td>Spicy Triple Double Crunchwrap</td>
      <td>780</td>
      <td>340</td>
      <td>38</td>
      <td>10.0</td>
      <td>0.5</td>
      <td>50</td>
      <td>1850</td>
      <td>87</td>
      <td>9.0</td>
      <td>8</td>
      <td>23.0</td>
      <td>20.0</td>
      <td>10.0</td>
      <td>25.0</td>
      <td>False</td>
    </tr>
    <tr>
      <th>511</th>
      <td>Taco Bell</td>
      <td>Express Taco Salad w/ Chips</td>
      <td>580</td>
      <td>260</td>
      <td>29</td>
      <td>9.0</td>
      <td>1.0</td>
      <td>60</td>
      <td>1270</td>
      <td>59</td>
      <td>8.0</td>
      <td>7</td>
      <td>23.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>True</td>
    </tr>
    <tr>
      <th>512</th>
      <td>Taco Bell</td>
      <td>Fiesta Taco Salad-Beef</td>
      <td>780</td>
      <td>380</td>
      <td>42</td>
      <td>10.0</td>
      <td>1.0</td>
      <td>60</td>
      <td>1340</td>
      <td>74</td>
      <td>11.0</td>
      <td>7</td>
      <td>26.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>True</td>
    </tr>
    <tr>
      <th>513</th>
      <td>Taco Bell</td>
      <td>Fiesta Taco Salad-Chicken</td>
      <td>720</td>
      <td>320</td>
      <td>35</td>
      <td>7.0</td>
      <td>0.0</td>
      <td>70</td>
      <td>1260</td>
      <td>70</td>
      <td>8.0</td>
      <td>8</td>
      <td>32.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>True</td>
    </tr>
    <tr>
      <th>514</th>
      <td>Taco Bell</td>
      <td>Fiesta Taco Salad-Steak</td>
      <td>720</td>
      <td>320</td>
      <td>36</td>
      <td>8.0</td>
      <td>1.0</td>
      <td>55</td>
      <td>1340</td>
      <td>70</td>
      <td>8.0</td>
      <td>8</td>
      <td>28.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>True</td>
    </tr>
  </tbody>
</table>
<p>515 rows × 17 columns</p>
</div>




```python
df_calories["is_salad"] = df_calories["is_salad"].astype("int")
```


```python
df_calories
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>item</th>
      <th>calories</th>
      <th>cal_fat</th>
      <th>total_fat</th>
      <th>sat_fat</th>
      <th>trans_fat</th>
      <th>cholesterol</th>
      <th>sodium</th>
      <th>total_carb</th>
      <th>fiber</th>
      <th>sugar</th>
      <th>protein</th>
      <th>vit_a</th>
      <th>vit_c</th>
      <th>calcium</th>
      <th>is_salad</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Mcdonalds</td>
      <td>Artisan Grilled Chicken Sandwich</td>
      <td>380</td>
      <td>60</td>
      <td>7</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>95</td>
      <td>1110</td>
      <td>44</td>
      <td>3.0</td>
      <td>11</td>
      <td>37.0</td>
      <td>4.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>Single Bacon Smokehouse Burger</td>
      <td>840</td>
      <td>410</td>
      <td>45</td>
      <td>17.0</td>
      <td>1.5</td>
      <td>130</td>
      <td>1580</td>
      <td>62</td>
      <td>2.0</td>
      <td>18</td>
      <td>46.0</td>
      <td>6.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mcdonalds</td>
      <td>Double Bacon Smokehouse Burger</td>
      <td>1130</td>
      <td>600</td>
      <td>67</td>
      <td>27.0</td>
      <td>3.0</td>
      <td>220</td>
      <td>1920</td>
      <td>63</td>
      <td>3.0</td>
      <td>18</td>
      <td>70.0</td>
      <td>10.0</td>
      <td>20.0</td>
      <td>50.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mcdonalds</td>
      <td>Grilled Bacon Smokehouse Chicken Sandwich</td>
      <td>750</td>
      <td>280</td>
      <td>31</td>
      <td>10.0</td>
      <td>0.5</td>
      <td>155</td>
      <td>1940</td>
      <td>62</td>
      <td>2.0</td>
      <td>18</td>
      <td>55.0</td>
      <td>6.0</td>
      <td>25.0</td>
      <td>20.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Mcdonalds</td>
      <td>Crispy Bacon Smokehouse Chicken Sandwich</td>
      <td>920</td>
      <td>410</td>
      <td>45</td>
      <td>12.0</td>
      <td>0.5</td>
      <td>120</td>
      <td>1980</td>
      <td>81</td>
      <td>4.0</td>
      <td>18</td>
      <td>46.0</td>
      <td>6.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>510</th>
      <td>Taco Bell</td>
      <td>Spicy Triple Double Crunchwrap</td>
      <td>780</td>
      <td>340</td>
      <td>38</td>
      <td>10.0</td>
      <td>0.5</td>
      <td>50</td>
      <td>1850</td>
      <td>87</td>
      <td>9.0</td>
      <td>8</td>
      <td>23.0</td>
      <td>20.0</td>
      <td>10.0</td>
      <td>25.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>511</th>
      <td>Taco Bell</td>
      <td>Express Taco Salad w/ Chips</td>
      <td>580</td>
      <td>260</td>
      <td>29</td>
      <td>9.0</td>
      <td>1.0</td>
      <td>60</td>
      <td>1270</td>
      <td>59</td>
      <td>8.0</td>
      <td>7</td>
      <td>23.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
    </tr>
    <tr>
      <th>512</th>
      <td>Taco Bell</td>
      <td>Fiesta Taco Salad-Beef</td>
      <td>780</td>
      <td>380</td>
      <td>42</td>
      <td>10.0</td>
      <td>1.0</td>
      <td>60</td>
      <td>1340</td>
      <td>74</td>
      <td>11.0</td>
      <td>7</td>
      <td>26.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
    </tr>
    <tr>
      <th>513</th>
      <td>Taco Bell</td>
      <td>Fiesta Taco Salad-Chicken</td>
      <td>720</td>
      <td>320</td>
      <td>35</td>
      <td>7.0</td>
      <td>0.0</td>
      <td>70</td>
      <td>1260</td>
      <td>70</td>
      <td>8.0</td>
      <td>8</td>
      <td>32.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
    </tr>
    <tr>
      <th>514</th>
      <td>Taco Bell</td>
      <td>Fiesta Taco Salad-Steak</td>
      <td>720</td>
      <td>320</td>
      <td>36</td>
      <td>8.0</td>
      <td>1.0</td>
      <td>55</td>
      <td>1340</td>
      <td>70</td>
      <td>8.0</td>
      <td>8</td>
      <td>28.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>515 rows × 17 columns</p>
</div>




```python
plt.figure(figsize=(20,20))

sns.catplot(x="calories", y="restaurant",

                hue="is_salad", ci=None,

                data=df_calories, color=None, linewidth=3, showfliers = False,

                orient="h", height=20, aspect=1, palette=None,

                kind="box", dodge=True)

plt.show()
```


    <Figure size 1440x1440 with 0 Axes>



    
![png](output_31_1.png)
    


### Problem 5


```python
df_calories.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>item</th>
      <th>calories</th>
      <th>cal_fat</th>
      <th>total_fat</th>
      <th>sat_fat</th>
      <th>trans_fat</th>
      <th>cholesterol</th>
      <th>sodium</th>
      <th>total_carb</th>
      <th>fiber</th>
      <th>sugar</th>
      <th>protein</th>
      <th>vit_a</th>
      <th>vit_c</th>
      <th>calcium</th>
      <th>is_salad</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Mcdonalds</td>
      <td>Artisan Grilled Chicken Sandwich</td>
      <td>380</td>
      <td>60</td>
      <td>7</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>95</td>
      <td>1110</td>
      <td>44</td>
      <td>3.0</td>
      <td>11</td>
      <td>37.0</td>
      <td>4.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>Single Bacon Smokehouse Burger</td>
      <td>840</td>
      <td>410</td>
      <td>45</td>
      <td>17.0</td>
      <td>1.5</td>
      <td>130</td>
      <td>1580</td>
      <td>62</td>
      <td>2.0</td>
      <td>18</td>
      <td>46.0</td>
      <td>6.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mcdonalds</td>
      <td>Double Bacon Smokehouse Burger</td>
      <td>1130</td>
      <td>600</td>
      <td>67</td>
      <td>27.0</td>
      <td>3.0</td>
      <td>220</td>
      <td>1920</td>
      <td>63</td>
      <td>3.0</td>
      <td>18</td>
      <td>70.0</td>
      <td>10.0</td>
      <td>20.0</td>
      <td>50.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mcdonalds</td>
      <td>Grilled Bacon Smokehouse Chicken Sandwich</td>
      <td>750</td>
      <td>280</td>
      <td>31</td>
      <td>10.0</td>
      <td>0.5</td>
      <td>155</td>
      <td>1940</td>
      <td>62</td>
      <td>2.0</td>
      <td>18</td>
      <td>55.0</td>
      <td>6.0</td>
      <td>25.0</td>
      <td>20.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Mcdonalds</td>
      <td>Crispy Bacon Smokehouse Chicken Sandwich</td>
      <td>920</td>
      <td>410</td>
      <td>45</td>
      <td>12.0</td>
      <td>0.5</td>
      <td>120</td>
      <td>1980</td>
      <td>81</td>
      <td>4.0</td>
      <td>18</td>
      <td>46.0</td>
      <td>6.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_calories["restaurant"].unique()
```




    array(['Mcdonalds', 'Chick Fil-A', 'Sonic', 'Arbys', 'Burger King',
           'Dairy Queen', 'Subway', 'Taco Bell'], dtype=object)




```python
df_new = df_calories[df_calories["restaurant"] != "Taco Bell"]
```


```python
df_new["restaurant"].unique()
```




    array(['Mcdonalds', 'Chick Fil-A', 'Sonic', 'Arbys', 'Burger King',
           'Dairy Queen', 'Subway'], dtype=object)




```python
df_new.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>item</th>
      <th>calories</th>
      <th>cal_fat</th>
      <th>total_fat</th>
      <th>sat_fat</th>
      <th>trans_fat</th>
      <th>cholesterol</th>
      <th>sodium</th>
      <th>total_carb</th>
      <th>fiber</th>
      <th>sugar</th>
      <th>protein</th>
      <th>vit_a</th>
      <th>vit_c</th>
      <th>calcium</th>
      <th>is_salad</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Mcdonalds</td>
      <td>Artisan Grilled Chicken Sandwich</td>
      <td>380</td>
      <td>60</td>
      <td>7</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>95</td>
      <td>1110</td>
      <td>44</td>
      <td>3.0</td>
      <td>11</td>
      <td>37.0</td>
      <td>4.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>Single Bacon Smokehouse Burger</td>
      <td>840</td>
      <td>410</td>
      <td>45</td>
      <td>17.0</td>
      <td>1.5</td>
      <td>130</td>
      <td>1580</td>
      <td>62</td>
      <td>2.0</td>
      <td>18</td>
      <td>46.0</td>
      <td>6.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mcdonalds</td>
      <td>Double Bacon Smokehouse Burger</td>
      <td>1130</td>
      <td>600</td>
      <td>67</td>
      <td>27.0</td>
      <td>3.0</td>
      <td>220</td>
      <td>1920</td>
      <td>63</td>
      <td>3.0</td>
      <td>18</td>
      <td>70.0</td>
      <td>10.0</td>
      <td>20.0</td>
      <td>50.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mcdonalds</td>
      <td>Grilled Bacon Smokehouse Chicken Sandwich</td>
      <td>750</td>
      <td>280</td>
      <td>31</td>
      <td>10.0</td>
      <td>0.5</td>
      <td>155</td>
      <td>1940</td>
      <td>62</td>
      <td>2.0</td>
      <td>18</td>
      <td>55.0</td>
      <td>6.0</td>
      <td>25.0</td>
      <td>20.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Mcdonalds</td>
      <td>Crispy Bacon Smokehouse Chicken Sandwich</td>
      <td>920</td>
      <td>410</td>
      <td>45</td>
      <td>12.0</td>
      <td>0.5</td>
      <td>120</td>
      <td>1980</td>
      <td>81</td>
      <td>4.0</td>
      <td>18</td>
      <td>46.0</td>
      <td>6.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_new.groupby(by="restaurant").median()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>calories</th>
      <th>cal_fat</th>
      <th>total_fat</th>
      <th>sat_fat</th>
      <th>trans_fat</th>
      <th>cholesterol</th>
      <th>sodium</th>
      <th>total_carb</th>
      <th>fiber</th>
      <th>sugar</th>
      <th>protein</th>
      <th>vit_a</th>
      <th>vit_c</th>
      <th>calcium</th>
      <th>is_salad</th>
    </tr>
    <tr>
      <th>restaurant</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Arbys</th>
      <td>550.0</td>
      <td>250.0</td>
      <td>28.0</td>
      <td>7.0</td>
      <td>0.0</td>
      <td>65.0</td>
      <td>1480.0</td>
      <td>46.0</td>
      <td>2.0</td>
      <td>6.0</td>
      <td>29.0</td>
      <td>6.0</td>
      <td>10.0</td>
      <td>15.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Burger King</th>
      <td>555.0</td>
      <td>285.0</td>
      <td>31.5</td>
      <td>8.0</td>
      <td>0.0</td>
      <td>85.0</td>
      <td>1150.0</td>
      <td>41.0</td>
      <td>2.0</td>
      <td>7.5</td>
      <td>29.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Chick Fil-A</th>
      <td>390.0</td>
      <td>126.0</td>
      <td>14.0</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>70.0</td>
      <td>1000.0</td>
      <td>29.0</td>
      <td>1.0</td>
      <td>4.0</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>8.0</td>
      <td>8.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Dairy Queen</th>
      <td>485.0</td>
      <td>220.0</td>
      <td>24.5</td>
      <td>9.0</td>
      <td>1.0</td>
      <td>60.0</td>
      <td>1030.0</td>
      <td>34.0</td>
      <td>2.0</td>
      <td>6.0</td>
      <td>23.0</td>
      <td>10.0</td>
      <td>4.0</td>
      <td>10.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Mcdonalds</th>
      <td>540.0</td>
      <td>240.0</td>
      <td>27.0</td>
      <td>7.0</td>
      <td>0.0</td>
      <td>95.0</td>
      <td>1120.0</td>
      <td>46.0</td>
      <td>3.0</td>
      <td>9.0</td>
      <td>33.0</td>
      <td>6.0</td>
      <td>15.0</td>
      <td>15.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Sonic</th>
      <td>570.0</td>
      <td>290.0</td>
      <td>32.0</td>
      <td>8.0</td>
      <td>0.0</td>
      <td>80.0</td>
      <td>1250.0</td>
      <td>44.0</td>
      <td>2.0</td>
      <td>7.0</td>
      <td>30.0</td>
      <td>6.0</td>
      <td>6.0</td>
      <td>15.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Subway</th>
      <td>460.0</td>
      <td>137.5</td>
      <td>15.0</td>
      <td>4.5</td>
      <td>0.0</td>
      <td>50.0</td>
      <td>1130.0</td>
      <td>47.0</td>
      <td>5.0</td>
      <td>8.0</td>
      <td>26.0</td>
      <td>16.0</td>
      <td>40.0</td>
      <td>35.0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_sales.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>average_sales</th>
      <th>us_sales</th>
      <th>num_company_stores</th>
      <th>num_franchised_stores</th>
      <th>unit_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Subway</td>
      <td>416.86</td>
      <td>10800.00</td>
      <td>0</td>
      <td>25908</td>
      <td>25908</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>2670.32</td>
      <td>37480.67</td>
      <td>842</td>
      <td>13194</td>
      <td>14036</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Starbucks</td>
      <td>945.27</td>
      <td>13167.61</td>
      <td>8222</td>
      <td>5708</td>
      <td>13930</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Dunkin Donuts</td>
      <td>733.13</td>
      <td>9192.00</td>
      <td>0</td>
      <td>12538</td>
      <td>12538</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Pizza Hut</td>
      <td>900.00</td>
      <td>5510.84</td>
      <td>96</td>
      <td>7426</td>
      <td>7522</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_sales["restaurant"].unique()
```




    array(['Subway', 'Mcdonalds', 'Starbucks', 'Dunkin Donuts', 'Pizza Hut',
           'Burger King', 'Taco Bell', 'Wendys', 'Dominos', 'Little Caesars',
           'KFC', 'Sonic', 'Arbys', 'Papa Johns', 'Jimmy Johns',
           'Baskin-Robbins', 'Chipotle', 'Jack in the Box', 'Popeyes'],
          dtype=object)




```python
df_new2 = df_sales[df_sales["restaurant"].str.contains('Arbys') | df_sales["restaurant"].str.contains('Sonic') | \
          df_sales["restaurant"].str.contains('Burger King') | df_sales["restaurant"].str.contains('Subway') | \
          df_sales["restaurant"].str.contains('Mcdonalds')]
```


```python
df_new2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>average_sales</th>
      <th>us_sales</th>
      <th>num_company_stores</th>
      <th>num_franchised_stores</th>
      <th>unit_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Subway</td>
      <td>416.86</td>
      <td>10800.00</td>
      <td>0</td>
      <td>25908</td>
      <td>25908</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>2670.32</td>
      <td>37480.67</td>
      <td>842</td>
      <td>13194</td>
      <td>14036</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Burger King</td>
      <td>1387.81</td>
      <td>10028.32</td>
      <td>50</td>
      <td>7196</td>
      <td>7266</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Sonic</td>
      <td>1250.00</td>
      <td>4408.16</td>
      <td>228</td>
      <td>3365</td>
      <td>3593</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Arbys</td>
      <td>1130.00</td>
      <td>3634.00</td>
      <td>1075</td>
      <td>2340</td>
      <td>3415</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_new3 = df_new2.sort_values(by="us_sales")
df_new3
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>restaurant</th>
      <th>average_sales</th>
      <th>us_sales</th>
      <th>num_company_stores</th>
      <th>num_franchised_stores</th>
      <th>unit_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>12</th>
      <td>Arbys</td>
      <td>1130.00</td>
      <td>3634.00</td>
      <td>1075</td>
      <td>2340</td>
      <td>3415</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Sonic</td>
      <td>1250.00</td>
      <td>4408.16</td>
      <td>228</td>
      <td>3365</td>
      <td>3593</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Burger King</td>
      <td>1387.81</td>
      <td>10028.32</td>
      <td>50</td>
      <td>7196</td>
      <td>7266</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Subway</td>
      <td>416.86</td>
      <td>10800.00</td>
      <td>0</td>
      <td>25908</td>
      <td>25908</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mcdonalds</td>
      <td>2670.32</td>
      <td>37480.67</td>
      <td>842</td>
      <td>13194</td>
      <td>14036</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(20,20))
sns.barplot(x="restaurant", y="us_sales", data=df_new3, ci=None)
plt.xlabel("Restaurants")
plt.ylabel("US Sales")
plt.show()
```


    
![png](output_44_0.png)
    



```python

```


```python

```
